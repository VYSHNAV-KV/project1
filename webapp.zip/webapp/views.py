from django.shortcuts import render,redirect
from capp.models import productdb,categorydb
from webapp.models import contactdb,signupdb

def home(request):
    cat=categorydb.objects.all()
    return render(request,'home.html',{'cat':cat})
def product_page(request):
    pro=productdb.objects.all()
    return render(request,'product_page.html',{'pro':pro})

def about_page(request):
    return render(request,'about_page.html')
def contact_page(request):
    return render(request,'contact_page.html')
def save_page(request):
    if request.method=="POST":
        a=request.POST.get('Name')
        b=request.POST.get('Mobile')
        c=request.POST.get('Email')
        d=request.POST.get('Message')
        data=contactdb(Name=a,Mobile=b,Email=c,Message=d)
        data.save()
        return redirect(contact_page)
def product_filtered(request,cat_name):
    data= productdb.objects.filter(Categoryname=cat_name)
    return render(request,'product_filtered.html',{'data':data})

def product_single(request,pro_id):
    data=productdb.objects.get(id=pro_id)
    return render(request,"product_single.html",{'data':data})
def signup_page(request):
    return render(request,'signup_page.html')
def signin_page(request):
    return render(request,'signin_page.html')

def save_signup(request):
    if request.method=="POST":
        a = request.POST.get('Name')
        b = request.POST.get('Mobile')
        c = request.POST.get('Email')
        d = request.POST.get('Password')
        e = request.POST.get('Re_password')
        data = signupdb(Name=a, Mobile=b, Email=c, Password=d,Re_password=e)
        data.save()
        return redirect(home)

# Create your views here.
