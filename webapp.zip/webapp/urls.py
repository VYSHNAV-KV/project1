from django.urls import path
from webapp import views
urlpatterns=[
    path('home/',views.home,name='home'),
    path('product_page/', views.product_page, name='product_page'),
    path('about_page/', views.about_page, name='about_page'),
    path('contact_page/', views.contact_page, name='contact_page'),
    path('save_page/', views.save_page, name='save_page'),
    path('product_filtered/<cat_name>/', views.product_filtered, name='product_filtered'),
    path('product_single/<int:pro_id>/', views.product_single, name='product_single'),
    path('signup_page/',views.signup_page,name='signup_page'),
    path('signin_page/', views.signin_page, name='signin_page'),
    path('save_signup/',views.save_signup,name='save_signup')
]